GKVM LICENSE SERVER - CUSTOM + UNLIMITED

This folder is separate from the GKVM panel. Deploy it to PythonAnywhere (or another server).

Supported validity:
- 1, 7, 30, 365, etc. days
- unlimited / infinite / never / 0 = no expiry

Supported activation limits:
- 1, 5, 10, etc.
- unlimited / infinite / 0 = unlimited activations

Examples:
30 days + 1 activation
90 days + 5 activations
Unlimited time + 1 activation
30 days + unlimited activations
Unlimited time + unlimited activations

PythonAnywhere:
1. Replace your license_server.py with this one.
2. Keep your existing licenses.db.
3. Set LICENSE_ADMIN_TOKEN in the PythonAnywhere environment/.env to your private admin token.
4. Keep LICENSE_PRODUCT=GVM-PANEL to preserve compatibility with the existing database/panel.
5. Reload/restart the PythonAnywhere web app.

Generate keys locally:
- Install Python and requests.
- Run generate-key.bat.
- Enter the admin token when prompted.
- Enter days or unlimited.
- Enter activation count or unlimited.

Security:
- Do NOT publish the admin token in the ZIP, screenshots, GitHub, or client panel.
- The panel only needs LICENSE_SERVER_URL and LICENSE_PRODUCT; it does not need the admin token.

---
Fixes applied when this was wired into the GKVM panel:
- Generated license keys now use the GKVM- prefix (was GTX-).
- Added POST /v1/deactivate {license_key, installation_id} to release an
  activation slot (the panel's "Deactivate" flow needs this; it was
  previously missing - there was no way to free up an activation without
  editing the database directly).
- Added light in-memory rate limiting (20 req/min per IP) on the public
  /v1/activate, /v1/check, /v1/deactivate endpoints - they take a
  license_key from an untrusted caller and had no abuse protection.
- IMPORTANT: LICENSE_PRODUCT is still "GVM-PANEL" by default, not
  "GKVM-PANEL", even though the panel itself has been rebranded to GKVM.
  This is intentional, per the original instructions above - it preserves
  compatibility with any licenses already issued under the existing
  product name/database. Do not change it unless you're intentionally
  starting a fresh license database.
