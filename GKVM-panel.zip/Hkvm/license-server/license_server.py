#!/usr/bin/env python3
import os, sqlite3, secrets, hashlib, hmac
from datetime import datetime, timezone, timedelta
from flask import Flask, request, jsonify

DB = os.getenv('LICENSE_DB', 'licenses.db')
ADMIN_TOKEN = os.getenv('LICENSE_ADMIN_TOKEN', 'change-me')
PRODUCT = os.getenv('LICENSE_PRODUCT', 'GVM-PANEL')
app = Flask(__name__)

# ---- lightweight rate limiting for the public (unauthenticated)
# endpoints - /v1/activate, /v1/check, /v1/deactivate all take a
# license_key from an untrusted caller. Admin endpoints are excluded
# since they already require ADMIN_TOKEN.
_rate_buckets = {}
def rate_limited(key, max_requests=20, window_seconds=60):
    now_ts = now().timestamp()
    bucket = _rate_buckets.setdefault(key, [])
    bucket[:] = [t for t in bucket if now_ts - t < window_seconds]
    if len(bucket) >= max_requests:
        return True
    bucket.append(now_ts)
    return False

@app.before_request
def _apply_rate_limit():
    if request.path in ('/v1/activate', '/v1/check', '/v1/deactivate'):
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr or 'unknown').split(',')[0].strip()
        if rate_limited(client_ip):
            return jsonify(valid=False, error='Too many requests - try again in a minute'), 429

def now():
    return datetime.now(timezone.utc)

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS licenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            license_key_hash TEXT UNIQUE NOT NULL,
            license_key_last4 TEXT NOT NULL,
            product TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT "active",
            expires_at TEXT,
            max_activations INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            notes TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS activations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            license_id INTEGER NOT NULL,
            installation_id TEXT NOT NULL,
            activated_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            UNIQUE(license_id, installation_id))''')

def kh(k):
    return hashlib.sha256(k.encode()).hexdigest()

def admin():
    return hmac.compare_digest(request.headers.get('X-License-Admin-Token', ''), ADMIN_TOKEN)

def newkey():
    x = secrets.token_hex(10).upper()
    return 'GKVM-' + '-'.join(x[i:i+5] for i in range(0, 20, 5))

def parse_days(value):
    if value is None or str(value).strip().lower() in ('', 'unlimited', 'infinite', 'never', '0'):
        return None
    days = int(value)
    if days < 1:
        raise ValueError('days must be a positive integer or unlimited')
    return days

def parse_activations(value):
    if value is None or str(value).strip().lower() in ('', 'unlimited', 'infinite', '0'):
        return 0  # 0 = unlimited
    n = int(value)
    if n < 1:
        raise ValueError('max_activations must be a positive integer or unlimited')
    return n

@app.get('/health')
def health():
    return jsonify(status='ok', product=PRODUCT)

@app.post('/v1/activate')
def activate():
    d = request.get_json(silent=True) or {}
    key = str(d.get('license_key', '')).strip()
    inst = str(d.get('installation_id', '')).strip()
    if not key or not inst:
        return jsonify(valid=False, error='license_key and installation_id are required'), 400
    with db() as c:
        l = c.execute('SELECT * FROM licenses WHERE license_key_hash=? AND product=?', (kh(key), PRODUCT)).fetchone()
        if not l:
            return jsonify(valid=False, error='Invalid license'), 404
        if l['status'] != 'active':
            return jsonify(valid=False, error='License is ' + l['status']), 403
        if l['expires_at'] and now() >= datetime.fromisoformat(l['expires_at']):
            c.execute('UPDATE licenses SET status="expired" WHERE id=?', (l['id'],))
            c.commit()
            return jsonify(valid=False, error='License expired'), 403
        e = c.execute('SELECT id FROM activations WHERE license_id=? AND installation_id=?', (l['id'], inst)).fetchone()
        n = c.execute('SELECT COUNT(*) FROM activations WHERE license_id=?', (l['id'],)).fetchone()[0]
        if not e and l['max_activations'] > 0 and n >= l['max_activations']:
            return jsonify(valid=False, error='Activation limit reached'), 403
        t = now().isoformat()
        if e:
            c.execute('UPDATE activations SET last_seen_at=? WHERE id=?', (t, e['id']))
        else:
            c.execute('INSERT INTO activations(license_id,installation_id,activated_at,last_seen_at) VALUES(?,?,?,?)', (l['id'], inst, t, t))
        c.commit()
        return jsonify(valid=True, license_id=l['id'], product=PRODUCT, status=l['status'],
                       expires_at=l['expires_at'], max_activations=l['max_activations'],
                       checked_at=t)

@app.post('/v1/check')
def check():
    return activate()

@app.post('/v1/deactivate')
def deactivate():
    d = request.get_json(silent=True) or {}
    key = str(d.get('license_key', '')).strip()
    inst = str(d.get('installation_id', '')).strip()
    if not key or not inst:
        return jsonify(success=False, error='license_key and installation_id are required'), 400
    with db() as c:
        l = c.execute('SELECT * FROM licenses WHERE license_key_hash=? AND product=?', (kh(key), PRODUCT)).fetchone()
        if not l:
            return jsonify(success=False, error='Invalid license'), 404
        c.execute('DELETE FROM activations WHERE license_id=? AND installation_id=?', (l['id'], inst))
        c.commit()
        return jsonify(success=True, released=c.total_changes > 0)

@app.post('/admin/licenses')
def create():
    if not admin():
        return jsonify(error='unauthorized'), 401
    d = request.get_json(silent=True) or {}
    try:
        days = parse_days(d.get('days'))
        max_activations = parse_activations(d.get('max_activations'))
    except (ValueError, TypeError) as e:
        return jsonify(error=str(e)), 400
    k = newkey()
    exp = (now() + timedelta(days=days)).isoformat() if days is not None else None
    with db() as c:
        c.execute('''INSERT INTO licenses
            (license_key_hash,license_key_last4,product,status,expires_at,max_activations,created_at,notes)
            VALUES(?,?,?,?,?,?,?,?)''',
            (kh(k), k[-4:], PRODUCT, 'active', exp, max_activations, now().isoformat(), str(d.get('notes', ''))))
        c.commit()
    return jsonify(license_key=k, product=PRODUCT, expires_at=exp,
                   max_activations=max_activations,
                   max_activations_label='UNLIMITED' if max_activations == 0 else max_activations)

@app.get('/admin/licenses')
def listing():
    if not admin():
        return jsonify(error='unauthorized'), 401
    with db() as c:
        rows = []
        for r in c.execute('SELECT id,license_key_last4,product,status,expires_at,max_activations,created_at,notes FROM licenses ORDER BY id DESC'):
            item = dict(r)
            item['validity'] = 'UNLIMITED' if item['expires_at'] is None else item['expires_at']
            item['activation_limit'] = 'UNLIMITED' if item['max_activations'] == 0 else item['max_activations']
            rows.append(item)
        return jsonify(rows)

@app.post('/admin/licenses/<int:lid>/revoke')
def revoke(lid):
    if not admin():
        return jsonify(error='unauthorized'), 401
    with db() as c:
        c.execute('UPDATE licenses SET status="revoked" WHERE id=?', (lid,))
        c.commit()
        return jsonify(success=c.total_changes > 0)

@app.post('/admin/licenses/<int:lid>/activate')
def reactivate(lid):
    if not admin():
        return jsonify(error='unauthorized'), 401
    with db() as c:
        c.execute('UPDATE licenses SET status="active" WHERE id=?', (lid,))
        c.commit()
        return jsonify(success=c.total_changes > 0)

if __name__ == '__main__':
    init()
    app.run(host=os.getenv('LICENSE_HOST', '0.0.0.0'), port=int(os.getenv('LICENSE_PORT', '9100')))
