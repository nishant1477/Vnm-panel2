#!/usr/bin/env node
// =====================================================================
// RDP UI test in a real DOM (jsdom): boots the real panel, loads the real
// VM detail pages over HTTP with their real scripts, then uses the RDP tab
// exactly like a person would - click the tab, Enable RDP, Copy, Disable.
// Not a full browser (no layout/CSS), but all page JavaScript, the CSRF
// fetch patch and every API call are the real thing.
// Needs: the rig from tests/build-test-guest.sh + tests/setup-ssh-guest.sh
//        and jsdom:  npm i --prefix /tmp/jsd jsdom   (JSDOM_PATH=/tmp/jsd/node_modules/jsdom)
// =====================================================================
const path = require('path');
const fs = require('fs');
const os = require('os');
const net = require('net');
const { spawn, execSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const sqlite3 = require(path.join(ROOT, 'node_modules/sqlite3'));
let jsdomLib;
try { jsdomLib = require(process.env.JSDOM_PATH || 'jsdom'); } catch (e) { console.log('jsdom not found: npm i --prefix /tmp/jsd jsdom && JSDOM_PATH=/tmp/jsd/node_modules/jsdom'); process.exit(2); }
const { JSDOM, CookieJar, VirtualConsole } = jsdomLib;

const RIG = process.env.VNM_TEST_DIR || '/tmp/vnm-rdp-test';
const PASS = 'Test#Pass123', PORT = 18091, SSHF = 22972;
const HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'vnm-ui-home-'));
const VMS = path.join(HOME, 'vms'), DBFILE = path.join(HOME, '.vnm', 'vnm.db');
const BASE = `http://127.0.0.1:${PORT}`;

const out = (s) => process.stdout.write(s + '\n');
const R = { pass: 0, fail: 0 }; const failed = [];
const ok = (c, m) => { if (c) { R.pass++; out('  PASS ' + m); } else { R.fail++; failed.push(m); out('  FAIL ' + m); } return !!c; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms = 30000, every = 250) { const end = Date.now() + ms; for (;;) { const v = await fn(); if (v) return v; if (Date.now() > end) return null; await sleep(every); } }
const sh = (c) => execSync(c, { stdio: 'pipe', shell: '/bin/bash' }).toString().trim();
const listening = (p) => new Promise((r) => { const s = net.connect(p, '127.0.0.1'); s.on('connect', () => { s.destroy(); r(true); }); s.on('error', () => r(false)); });

let panel = null, panelLog = '';
async function bootPanel() {
  panel = spawn(process.execPath, ['app.js'], { cwd: ROOT, env: { ...process.env, HOME, PORT: String(PORT), QEMU_BIN: path.join(RIG, 'qemu-system-x86_64'), NODE_ENV: 'development' }, stdio: ['ignore', 'pipe', 'pipe'] });
  panel.stdout.on('data', (d) => { panelLog += d; }); panel.stderr.on('data', (d) => { panelLog += d; });
  if (!(await waitFor(() => /Open http:\/\/localhost:/.test(panelLog), 60000, 300))) throw new Error('panel did not start');
}
const stopAll = async () => { try { panel && panel.kill('SIGKILL'); } catch (e) { /* gone */ } try { sh('pkill -x qemu-system-x86 || true'); } catch (e) { /* ignore */ } };

// plain-fetch session used for setup (login, start VM) and shared with the DOM
const cookies = {};
async function http(method, p, body) {
  const headers = { Cookie: Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join('; ') };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET' && cookies.csrf_token) headers['x-csrf-token'] = cookies.csrf_token;
  const res = await fetch(BASE + p, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual' });
  for (const c of res.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); cookies[kv.slice(0, i)] = kv.slice(i + 1); }
  const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch (e) { /* html */ }
  return { code: res.status, json, text };
}
const dbRun = (s, p = []) => new Promise((res, rej) => { const d = new sqlite3.Database(DBFILE); d.run(s, p, function (e) { d.close(); e ? rej(e) : res(this); }); });
const dbGet = (s, p = []) => new Promise((res, rej) => { const d = new sqlite3.Database(DBFILE); d.get(s, p, (e, r) => { d.close(); e ? rej(e) : res(r); }); });

// open a page in jsdom with the logged-in cookies and a real fetch
async function openPage(urlPath, errors) {
  const jar = new CookieJar();
  for (const [k, v] of Object.entries(cookies)) jar.setCookieSync(`${k}=${v}; Path=/`, BASE);
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errors.push('jsdomError: ' + (e.detail || e.message || e)));
  vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
  const clip = []; 
  const dom = await JSDOM.fromURL(BASE + urlPath, {
    cookieJar: jar, runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(window) {
      window.fetch = async (u, o = {}) => {
        const abs = new URL(u, BASE).href;
        const headers = Object.assign({}, o.headers, { Cookie: jar.getCookieStringSync(abs) });
        const res = await fetch(abs, Object.assign({}, o, { headers, redirect: 'manual' }));
        for (const c of res.headers.getSetCookie()) jar.setCookieSync(c, abs);
        return res;
      };
      window.matchMedia = window.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));
      window.confirm = () => true; window.alert = () => {};
      Object.defineProperty(window.navigator, 'clipboard', { value: { writeText: (t) => { clip.push(t); return Promise.resolve(); } } });
      window.WebSocket = class { constructor() { setTimeout(() => this.onerror && this.onerror(new Error('no ws in test')), 0); } close() {} send() {} };
      window.EventSource = class { constructor() {} close() {} };
    }
  });
  dom.clip = clip;
  await new Promise((r) => (dom.window.document.readyState === 'complete' ? r() : dom.window.addEventListener('load', r)));
  return dom;
}
const panelText = (dom) => (dom.window.document.getElementById('rdpPanel') || { textContent: '' }).textContent.replace(/\s+/g, ' ');
const badge = (dom) => { const t = panelText(dom); return ['ONLINE', 'OFFLINE', 'INSTALLING', 'RESTART REQUIRED', 'UNSUPPORTED OS', 'ERROR', 'DISABLED'].find((b) => t.includes(b)) || null; };
const btn = (dom, label) => [...dom.window.document.querySelectorAll('#rdpPanel button')].find((b) => b.textContent.includes(label));

(async () => {
  if (!fs.existsSync(path.join(RIG, 'qemu-system-x86_64')) || !(await listening(2299))) { out('Prerequisites missing: run tests/build-test-guest.sh and tests/setup-ssh-guest.sh'); process.exit(2); }
  sh('pkill -x qemu-system-x86 || true');
  fs.mkdirSync(VMS, { recursive: true });
  await bootPanel();
  const pw = (/username: admin\s+password: (\S+)/.exec(panelLog) || [])[1];
  await http('GET', '/login');
  const lg = await http('POST', '/api/login', { username: 'admin', password: pw });
  if (!(lg.json && lg.json.success)) throw new Error('login failed');

  execSync(`qemu-img create -f qcow2 ${path.join(VMS, 'vm-1-disk.qcow2')} 64M`, { stdio: 'pipe' });
  await dbRun(`INSERT INTO vms (vm_name, os_type, template_type, username, password, memory, cpus, cpu_sockets, cpu_cores, cpu_threads, cpu_model, enable_kvm, disk_file, status, network_type, ssh_port, owner_id)
               VALUES ('rig-vm','Ubuntu 22.04','ubuntu','tester',?,256,1,1,1,1,'qemu64',0,?,'stopped','nat',?,1)`, [PASS, path.join(VMS, 'vm-1-disk.qcow2'), SSHF]);

  for (const [name, urlPath] of [['ADMIN VM page', '/admin/vm/1'], ['USER VM page', '/vm/1']]) {
    out(`\n== ${name} (${urlPath}) - real DOM, VM stopped`);
    const errors = [];
    const dom = await openPage(urlPath, errors);
    const d = dom.window.document;
    // the page renders its tab bar from JavaScript after /api/vms/:id returns
    await waitFor(() => d.querySelector('.tab-btn[data-tab="overview"]'), 20000, 200);
    const tabBtn = d.querySelector('.tab-btn[data-tab="rdp"]');
    ok(!!tabBtn && /RDP/.test(tabBtn.textContent), 'an "RDP" tab button is in the tab bar');
    const order = [...d.querySelectorAll('.tab-btn')].map((b) => b.dataset.tab).join(' > ');
    ok(/overview > network > rdp > hardware/.test(order), `tab order: ${order}`);
    ok(!d.getElementById('tab-rdp').classList.contains('active'), 'RDP pane hidden until clicked');
    tabBtn.click();
    ok(d.getElementById('tab-rdp').classList.contains('active') && tabBtn.classList.contains('active') && !d.getElementById('tab-overview').classList.contains('active'), 'clicking the tab shows the RDP pane (and hides Overview)');
    ok(!!(await waitFor(() => badge(dom), 15000)), 'the RDP panel loads its status from the API');
    ok(badge(dom) === 'DISABLED' && /Remote Desktop \(RDP\)/.test(panelText(dom)), `status badge: ${badge(dom)}`);
    const en = btn(dom, 'Enable RDP');
    ok(!!en && en.disabled, 'Enable RDP button is shown but disabled while the VM is stopped');
    ok(errors.length === 0, `no JavaScript errors on the page${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
    dom.window.close();
  }

  out('\n== start the VM through the panel, then use the tab like a person');
  const st = await http('POST', '/api/vms/1/start'); ok(st.json && st.json.success, 'VM started via the panel');
  ok(!!(await waitFor(() => fs.existsSync(path.join(VMS, 'vm-1.log')) && /VNM_TEST_GUEST_READY/.test(fs.readFileSync(path.join(VMS, 'vm-1.log'), 'utf8')), 90000, 500)), 'guest booted');
  await sleep(1500);

  const errors = [];
  const dom = await openPage('/admin/vm/1', errors);
  const d = dom.window.document;
  await waitFor(() => d.querySelector('.tab-btn[data-tab="rdp"]'), 20000, 200);
  d.querySelector('.tab-btn[data-tab="rdp"]').click();
  await waitFor(() => badge(dom), 15000);
  const en = btn(dom, 'Enable RDP');
  ok(!!en && !en.disabled, 'with the VM running, Enable RDP is clickable');
  en.click();
  ok(!!(await waitFor(() => badge(dom) === 'INSTALLING', 15000, 200)), 'after clicking: badge changes to INSTALLING with progress text');
  const seenSteps = new Set();
  const final = await waitFor(() => { if (badge(dom) === 'INSTALLING') seenSteps.add(panelText(dom).slice(-80)); return ['ONLINE', 'ERROR', 'OFFLINE'].includes(badge(dom)) ? badge(dom) : null; }, 300000, 400);
  ok(final === 'ONLINE', `the page reaches ONLINE on its own by polling (got ${final})`);
  const addr = (d.getElementById('rdpConnect') || {}).textContent;
  const row = await dbGet('SELECT rdp_port FROM vms WHERE vm_id=1');
  ok(/^127\.0\.0\.1:\d{5}$/.test(addr || '') && addr.endsWith(':' + row.rdp_port), `connection address shown: ${addr}`);
  const t = panelText(dom);
  ok(/RDP Host/.test(t) && /RDP Port/.test(t) && /Username/.test(t) && /tester/.test(t) && /Ubuntu/.test(t), 'host, port, username and guest OS are displayed');
  ok(!t.includes(PASS), 'the password is not displayed anywhere');
  btn(dom, 'Copy').click(); await sleep(200);
  ok(dom.clip.includes(addr), 'the Copy button puts the connection address on the clipboard');
  ok(!!btn(dom, 'Disable RDP') && !!btn(dom, 'Re-run setup'), 'Disable RDP and Re-run setup buttons are available once enabled');
  btn(dom, 'Disable RDP').click();
  ok(!!(await waitFor(() => badge(dom) === 'DISABLED', 20000, 250)), 'clicking Disable RDP returns the tab to DISABLED');
  ok(!(await listening(row.rdp_port)) && (await dbGet('SELECT rdp_port p FROM vms WHERE vm_id=1')).p === null, 'port released on the host');
  ok(!!btn(dom, 'Enable RDP') && !btn(dom, 'Enable RDP').disabled, 'Enable RDP is offered again');
  ok(errors.length === 0, `no JavaScript errors during the whole flow${errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''}`);
  dom.window.close();

  out(`\n${R.pass} passed, ${R.fail} failed`);
  if (failed.length) out('Failures:\n - ' + failed.join('\n - '));
  await stopAll();
  process.exit(R.fail ? 1 : 0);
})().catch(async (e) => { out('HARNESS ERROR: ' + (e.stack || e)); out(panelLog.slice(-1500)); await stopAll(); process.exit(2); });
